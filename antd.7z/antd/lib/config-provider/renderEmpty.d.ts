import * as React from 'react';
declare const renderEmpty: (componentName?: string | undefined) => React.ReactNode;
export declare type RenderEmptyHandler = typeof renderEmpty;
export default renderEmpty;
