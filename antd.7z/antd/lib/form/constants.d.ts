export declare const FIELD_META_PROP = "data-__meta";
export declare const FIELD_DATA_PROP = "data-__field";
