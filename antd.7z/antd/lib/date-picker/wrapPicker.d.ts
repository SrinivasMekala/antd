import * as React from 'react';
declare type PickerType = 'date' | 'week' | 'month';
export default function wrapPicker(Picker: React.ComponentClass<any>, pickerType: PickerType): any;
export {};
