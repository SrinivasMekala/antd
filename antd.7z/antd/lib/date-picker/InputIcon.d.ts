import * as React from 'react';
export default function InputIcon(props: {
    suffixIcon: React.ReactNode;
    prefixCls: string;
}): JSX.Element;
