import * as moment from 'moment';
export declare function formatDate(value: moment.Moment | undefined | null, format: string | string[] | undefined): string;
