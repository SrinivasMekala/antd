declare const locale: {
    lang: any;
    timePickerLocale: {
        placeholder: string;
    };
    dateFormat: string;
    monthFormat: string;
    dateTimeFormat: string;
    weekFormat: string;
};
export default locale;
