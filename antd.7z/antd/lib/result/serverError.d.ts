/// <reference types="react" />
declare const ServerError: () => JSX.Element;
export default ServerError;
