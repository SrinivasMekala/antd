import * as React from 'react';
import { BlockProps } from './Base';
interface ParagraphProps extends BlockProps {
}
declare const Paragraph: React.SFC<ParagraphProps>;
export default Paragraph;
