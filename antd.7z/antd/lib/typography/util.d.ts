import * as React from 'react';
declare const _default: (originEle: HTMLElement, rows: number, content: React.ReactNode, fixedContent: React.ReactNode[], ellipsisStr: string) => {
    content: React.ReactNode;
    text: string;
    ellipsis: boolean;
};
export default _default;
