import Statistic from './Statistic';
export default Statistic;
