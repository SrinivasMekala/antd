import locale from '../locale/de_DE';
export default locale;
