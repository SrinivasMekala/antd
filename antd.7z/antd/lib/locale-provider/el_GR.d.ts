import locale from '../locale/el_GR';
export default locale;
