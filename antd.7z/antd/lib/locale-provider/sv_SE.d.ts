import locale from '../locale/sv_SE';
export default locale;
