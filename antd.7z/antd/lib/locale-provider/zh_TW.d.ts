import locale from '../locale/zh_TW';
export default locale;
