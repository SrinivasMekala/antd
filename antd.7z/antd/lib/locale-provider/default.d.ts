import locale from '../locale/default';
export default locale;
