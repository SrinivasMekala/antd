import locale from '../locale/en_GB';
export default locale;
