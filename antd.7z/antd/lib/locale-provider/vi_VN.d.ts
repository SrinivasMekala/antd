import locale from '../locale/vi_VN';
export default locale;
