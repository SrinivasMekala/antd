import locale from '../locale/ar_EG';
export default locale;
