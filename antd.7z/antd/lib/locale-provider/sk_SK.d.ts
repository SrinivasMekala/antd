import locale from '../locale/sk_SK';
export default locale;
