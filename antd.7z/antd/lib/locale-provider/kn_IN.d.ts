import locale from '../locale/kn_IN';
export default locale;
