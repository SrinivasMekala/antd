import locale from '../locale/ko_KR';
export default locale;
