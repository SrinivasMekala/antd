import locale from '../locale/fr_BE';
export default locale;
