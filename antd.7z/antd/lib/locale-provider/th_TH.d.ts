import locale from '../locale/th_TH';
export default locale;
