import locale from '../locale/mn_MN';
export default locale;
