import locale from '../locale/fi_FI';
export default locale;
