export declare function setTwoToneColor(primaryColor: string): void;
export declare function getTwoToneColor(): string;
