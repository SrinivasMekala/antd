export declare function validProgress(progress: number | undefined): number;
