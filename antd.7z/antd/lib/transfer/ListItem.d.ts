import * as React from 'react';
export default class ListItem extends React.Component<any, any> {
    shouldComponentUpdate(...args: any[]): any;
    render(): JSX.Element;
}
