# History
----

## 1.5.0 / 2018-11-12

- support startEventListenter

## 1.4.0 / 2017-08-16

- add es version

## 1.3.0 / 2016-08-01

- support animationName as object

