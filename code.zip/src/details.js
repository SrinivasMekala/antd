import React from 'react';
import ReactDOM from "react-dom";
import {
  BrowserRouter as Router,
  useParams
} from "react-router-dom";
function Details() {
    let { id } = useParams();
    return (
      <div>
        <h3>Detail Page for {id}</h3>
      </div>
    );
  }
  
  export default Details;
  