# @ant-design/create-react-context

[![npm package](https://img.shields.io/npm/v/@ant-design/create-react-context.svg?style=flat-square)](https://www.npmjs.org/package/@ant-design/create-react-context)
[![NPM downloads](http://img.shields.io/npm/dm/@ant-design/create-react-context.svg?style=flat-square)](http://npmjs.com/package/@ant-design/create-react-context)

A fork of [create-react-context](https://github.com/jamiebuilds/create-react-context) in MIT license.

```
npm install @ant-design/create-react-context
```
## License

MIT.
