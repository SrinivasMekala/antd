import { IconDefinition } from '../types';
declare const UsergroupAddOutline: IconDefinition;
export default UsergroupAddOutline;
