import { IconDefinition } from '../types';
declare const TaobaoOutline: IconDefinition;
export default TaobaoOutline;
