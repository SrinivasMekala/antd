import { IconDefinition } from '../types';
declare const UsbOutline: IconDefinition;
export default UsbOutline;
