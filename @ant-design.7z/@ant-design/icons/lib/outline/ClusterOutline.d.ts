import { IconDefinition } from '../types';
declare const ClusterOutline: IconDefinition;
export default ClusterOutline;
