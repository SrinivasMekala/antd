import { IconDefinition } from '../types';
declare const ShoppingCartOutline: IconDefinition;
export default ShoppingCartOutline;
