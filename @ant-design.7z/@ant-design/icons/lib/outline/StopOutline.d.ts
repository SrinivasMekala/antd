import { IconDefinition } from '../types';
declare const StopOutline: IconDefinition;
export default StopOutline;
