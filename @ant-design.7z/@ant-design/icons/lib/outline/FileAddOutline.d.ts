import { IconDefinition } from '../types';
declare const FileAddOutline: IconDefinition;
export default FileAddOutline;
