import { IconDefinition } from '../types';
declare const DeploymentUnitOutline: IconDefinition;
export default DeploymentUnitOutline;
