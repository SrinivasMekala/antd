import { IconDefinition } from '../types';
declare const UnderlineOutline: IconDefinition;
export default UnderlineOutline;
