import { IconDefinition } from '../types';
declare const VideoCameraOutline: IconDefinition;
export default VideoCameraOutline;
