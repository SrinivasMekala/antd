import { IconDefinition } from '../types';
declare const UserDeleteOutline: IconDefinition;
export default UserDeleteOutline;
