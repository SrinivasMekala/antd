import { IconDefinition } from '../types';
declare const TaobaoCircleOutline: IconDefinition;
export default TaobaoCircleOutline;
