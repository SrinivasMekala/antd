import { IconDefinition } from '../types';
declare const StockOutline: IconDefinition;
export default StockOutline;
