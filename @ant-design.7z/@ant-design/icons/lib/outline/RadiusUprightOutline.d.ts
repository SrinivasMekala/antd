import { IconDefinition } from '../types';
declare const RadiusUprightOutline: IconDefinition;
export default RadiusUprightOutline;
