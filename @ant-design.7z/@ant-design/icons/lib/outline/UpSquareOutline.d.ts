import { IconDefinition } from '../types';
declare const UpSquareOutline: IconDefinition;
export default UpSquareOutline;
