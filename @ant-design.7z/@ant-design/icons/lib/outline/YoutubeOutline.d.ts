import { IconDefinition } from '../types';
declare const YoutubeOutline: IconDefinition;
export default YoutubeOutline;
