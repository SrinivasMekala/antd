import { IconDefinition } from '../types';
declare const LayoutOutline: IconDefinition;
export default LayoutOutline;
