import { IconDefinition } from '../types';
declare const SlackSquareOutline: IconDefinition;
export default SlackSquareOutline;
