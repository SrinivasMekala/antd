import { IconDefinition } from '../types';
declare const HddOutline: IconDefinition;
export default HddOutline;
