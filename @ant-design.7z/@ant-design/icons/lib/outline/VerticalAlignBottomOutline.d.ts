import { IconDefinition } from '../types';
declare const VerticalAlignBottomOutline: IconDefinition;
export default VerticalAlignBottomOutline;
