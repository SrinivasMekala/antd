import { IconDefinition } from '../types';
declare const VerticalLeftOutline: IconDefinition;
export default VerticalLeftOutline;
