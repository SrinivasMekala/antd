import { IconDefinition } from '../types';
declare const WeiboOutline: IconDefinition;
export default WeiboOutline;
