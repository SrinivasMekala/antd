import { IconDefinition } from '../types';
declare const VerticalRightOutline: IconDefinition;
export default VerticalRightOutline;
