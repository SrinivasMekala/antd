import { IconDefinition } from '../types';
declare const StrikethroughOutline: IconDefinition;
export default StrikethroughOutline;
