import { IconDefinition } from '../types';
declare const StarOutline: IconDefinition;
export default StarOutline;
