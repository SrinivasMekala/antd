import { IconDefinition } from '../types';
declare const SmallDashOutline: IconDefinition;
export default SmallDashOutline;
