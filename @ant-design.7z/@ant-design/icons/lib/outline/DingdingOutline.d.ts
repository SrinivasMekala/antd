import { IconDefinition } from '../types';
declare const DingdingOutline: IconDefinition;
export default DingdingOutline;
