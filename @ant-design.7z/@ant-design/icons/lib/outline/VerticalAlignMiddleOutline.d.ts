import { IconDefinition } from '../types';
declare const VerticalAlignMiddleOutline: IconDefinition;
export default VerticalAlignMiddleOutline;
