import { IconDefinition } from '../types';
declare const ZoomOutOutline: IconDefinition;
export default ZoomOutOutline;
