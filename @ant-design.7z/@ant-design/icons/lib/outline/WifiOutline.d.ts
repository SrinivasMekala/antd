import { IconDefinition } from '../types';
declare const WifiOutline: IconDefinition;
export default WifiOutline;
