import { IconDefinition } from '../types';
declare const ShareAltOutline: IconDefinition;
export default ShareAltOutline;
