import { IconDefinition } from '../types';
declare const UploadOutline: IconDefinition;
export default UploadOutline;
