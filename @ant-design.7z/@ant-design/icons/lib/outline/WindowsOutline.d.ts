import { IconDefinition } from '../types';
declare const WindowsOutline: IconDefinition;
export default WindowsOutline;
