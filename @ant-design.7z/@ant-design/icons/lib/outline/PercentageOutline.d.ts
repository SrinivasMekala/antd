import { IconDefinition } from '../types';
declare const PercentageOutline: IconDefinition;
export default PercentageOutline;
