import { IconDefinition } from '../types';
declare const SyncOutline: IconDefinition;
export default SyncOutline;
