import { IconDefinition } from '../types';
declare const SnippetsOutline: IconDefinition;
export default SnippetsOutline;
