import { IconDefinition } from '../types';
declare const RobotOutline: IconDefinition;
export default RobotOutline;
