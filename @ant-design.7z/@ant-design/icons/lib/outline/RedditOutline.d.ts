import { IconDefinition } from '../types';
declare const RedditOutline: IconDefinition;
export default RedditOutline;
