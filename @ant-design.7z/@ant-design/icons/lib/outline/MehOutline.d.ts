import { IconDefinition } from '../types';
declare const MehOutline: IconDefinition;
export default MehOutline;
