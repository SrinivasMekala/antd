import { IconDefinition } from '../types';
declare const LinkedinOutline: IconDefinition;
export default LinkedinOutline;
