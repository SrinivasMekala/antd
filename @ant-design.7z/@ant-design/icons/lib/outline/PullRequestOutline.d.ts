import { IconDefinition } from '../types';
declare const PullRequestOutline: IconDefinition;
export default PullRequestOutline;
