import { IconDefinition } from '../types';
declare const WalletOutline: IconDefinition;
export default WalletOutline;
