import { IconDefinition } from '../types';
declare const ShakeOutline: IconDefinition;
export default ShakeOutline;
