import { IconDefinition } from '../types';
declare const SolutionOutline: IconDefinition;
export default SolutionOutline;
