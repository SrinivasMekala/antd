import { IconDefinition } from '../types';
declare const MedicineBoxOutline: IconDefinition;
export default MedicineBoxOutline;
