import { IconDefinition } from '../types';
declare const SwapLeftOutline: IconDefinition;
export default SwapLeftOutline;
