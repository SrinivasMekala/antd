import { IconDefinition } from '../types';
declare const SelectOutline: IconDefinition;
export default SelectOutline;
