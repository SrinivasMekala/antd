import { IconDefinition } from '../types';
declare const SlidersOutline: IconDefinition;
export default SlidersOutline;
