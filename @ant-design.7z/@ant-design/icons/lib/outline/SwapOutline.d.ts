import { IconDefinition } from '../types';
declare const SwapOutline: IconDefinition;
export default SwapOutline;
