import { IconDefinition } from '../types';
declare const AppstoreOutline: IconDefinition;
export default AppstoreOutline;
