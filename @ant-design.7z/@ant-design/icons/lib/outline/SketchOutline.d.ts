import { IconDefinition } from '../types';
declare const SketchOutline: IconDefinition;
export default SketchOutline;
