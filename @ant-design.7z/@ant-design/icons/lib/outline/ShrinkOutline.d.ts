import { IconDefinition } from '../types';
declare const ShrinkOutline: IconDefinition;
export default ShrinkOutline;
