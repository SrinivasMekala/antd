import { IconDefinition } from '../types';
declare const SafetyOutline: IconDefinition;
export default SafetyOutline;
