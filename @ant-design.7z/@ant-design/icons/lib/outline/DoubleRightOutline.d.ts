import { IconDefinition } from '../types';
declare const DoubleRightOutline: IconDefinition;
export default DoubleRightOutline;
