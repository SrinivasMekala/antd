import { IconDefinition } from '../types';
declare const DownOutline: IconDefinition;
export default DownOutline;
