import { IconDefinition } from '../types';
declare const FullscreenOutline: IconDefinition;
export default FullscreenOutline;
