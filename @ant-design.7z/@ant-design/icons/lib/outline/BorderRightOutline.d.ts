import { IconDefinition } from '../types';
declare const BorderRightOutline: IconDefinition;
export default BorderRightOutline;
