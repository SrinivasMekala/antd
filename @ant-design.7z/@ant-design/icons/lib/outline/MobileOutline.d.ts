import { IconDefinition } from '../types';
declare const MobileOutline: IconDefinition;
export default MobileOutline;
