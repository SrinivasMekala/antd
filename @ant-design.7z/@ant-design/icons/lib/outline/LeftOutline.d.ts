import { IconDefinition } from '../types';
declare const LeftOutline: IconDefinition;
export default LeftOutline;
