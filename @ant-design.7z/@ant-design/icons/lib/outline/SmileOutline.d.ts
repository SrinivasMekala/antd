import { IconDefinition } from '../types';
declare const SmileOutline: IconDefinition;
export default SmileOutline;
