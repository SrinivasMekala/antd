import { IconDefinition } from '../types';
declare const UsergroupDeleteOutline: IconDefinition;
export default UsergroupDeleteOutline;
