import { IconDefinition } from '../types';
declare const CodeOutline: IconDefinition;
export default CodeOutline;
