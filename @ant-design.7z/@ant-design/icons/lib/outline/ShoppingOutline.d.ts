import { IconDefinition } from '../types';
declare const ShoppingOutline: IconDefinition;
export default ShoppingOutline;
