import { IconDefinition } from '../types';
declare const SoundOutline: IconDefinition;
export default SoundOutline;
