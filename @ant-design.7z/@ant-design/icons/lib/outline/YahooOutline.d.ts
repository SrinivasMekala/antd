import { IconDefinition } from '../types';
declare const YahooOutline: IconDefinition;
export default YahooOutline;
