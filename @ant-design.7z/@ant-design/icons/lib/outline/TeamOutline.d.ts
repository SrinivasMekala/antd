import { IconDefinition } from '../types';
declare const TeamOutline: IconDefinition;
export default TeamOutline;
