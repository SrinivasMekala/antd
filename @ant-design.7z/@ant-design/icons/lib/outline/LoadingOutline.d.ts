import { IconDefinition } from '../types';
declare const LoadingOutline: IconDefinition;
export default LoadingOutline;
