import { IconDefinition } from '../types';
declare const WarningOutline: IconDefinition;
export default WarningOutline;
