import { IconDefinition } from '../types';
declare const TwitterOutline: IconDefinition;
export default TwitterOutline;
