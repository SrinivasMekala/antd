import { IconDefinition } from '../types';
declare const BulbOutline: IconDefinition;
export default BulbOutline;
