import { IconDefinition } from '../types';
declare const ColumHeightOutline: IconDefinition;
export default ColumHeightOutline;
