import { IconDefinition } from '../types';
declare const BorderVerticleOutline: IconDefinition;
export default BorderVerticleOutline;
