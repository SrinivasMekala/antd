import { IconDefinition } from '../types';
declare const GoogleOutline: IconDefinition;
export default GoogleOutline;
