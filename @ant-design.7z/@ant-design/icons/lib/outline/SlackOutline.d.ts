import { IconDefinition } from '../types';
declare const SlackOutline: IconDefinition;
export default SlackOutline;
