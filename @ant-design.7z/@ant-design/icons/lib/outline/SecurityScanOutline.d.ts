import { IconDefinition } from '../types';
declare const SecurityScanOutline: IconDefinition;
export default SecurityScanOutline;
