import { IconDefinition } from '../types';
declare const OrderedListOutline: IconDefinition;
export default OrderedListOutline;
