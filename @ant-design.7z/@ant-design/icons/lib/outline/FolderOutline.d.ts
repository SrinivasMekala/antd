import { IconDefinition } from '../types';
declare const FolderOutline: IconDefinition;
export default FolderOutline;
