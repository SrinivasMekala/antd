import { IconDefinition } from '../types';
declare const UserAddOutline: IconDefinition;
export default UserAddOutline;
