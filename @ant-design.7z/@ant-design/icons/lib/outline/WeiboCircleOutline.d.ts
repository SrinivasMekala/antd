import { IconDefinition } from '../types';
declare const WeiboCircleOutline: IconDefinition;
export default WeiboCircleOutline;
