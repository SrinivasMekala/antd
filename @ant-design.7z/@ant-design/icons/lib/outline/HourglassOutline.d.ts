import { IconDefinition } from '../types';
declare const HourglassOutline: IconDefinition;
export default HourglassOutline;
