import { IconDefinition } from '../types';
declare const AmazonOutline: IconDefinition;
export default AmazonOutline;
