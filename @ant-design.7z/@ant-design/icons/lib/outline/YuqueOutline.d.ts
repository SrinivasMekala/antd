import { IconDefinition } from '../types';
declare const YuqueOutline: IconDefinition;
export default YuqueOutline;
