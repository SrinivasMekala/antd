import { IconDefinition } from '../types';
declare const SettingOutline: IconDefinition;
export default SettingOutline;
