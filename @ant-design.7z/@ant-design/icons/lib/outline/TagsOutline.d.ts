import { IconDefinition } from '../types';
declare const TagsOutline: IconDefinition;
export default TagsOutline;
