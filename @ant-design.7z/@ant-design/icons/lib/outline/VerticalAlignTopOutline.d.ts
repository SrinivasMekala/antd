import { IconDefinition } from '../types';
declare const VerticalAlignTopOutline: IconDefinition;
export default VerticalAlignTopOutline;
