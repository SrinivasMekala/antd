import { IconDefinition } from '../types';
declare const SortAscendingOutline: IconDefinition;
export default SortAscendingOutline;
