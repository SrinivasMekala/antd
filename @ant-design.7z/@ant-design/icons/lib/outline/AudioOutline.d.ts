import { IconDefinition } from '../types';
declare const AudioOutline: IconDefinition;
export default AudioOutline;
