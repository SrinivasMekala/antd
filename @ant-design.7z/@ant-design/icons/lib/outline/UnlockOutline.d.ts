import { IconDefinition } from '../types';
declare const UnlockOutline: IconDefinition;
export default UnlockOutline;
