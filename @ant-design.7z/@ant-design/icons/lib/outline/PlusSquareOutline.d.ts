import { IconDefinition } from '../types';
declare const PlusSquareOutline: IconDefinition;
export default PlusSquareOutline;
