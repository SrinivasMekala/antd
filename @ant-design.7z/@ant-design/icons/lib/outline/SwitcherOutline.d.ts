import { IconDefinition } from '../types';
declare const SwitcherOutline: IconDefinition;
export default SwitcherOutline;
