import { IconDefinition } from '../types';
declare const FontColorsOutline: IconDefinition;
export default FontColorsOutline;
