import { IconDefinition } from '../types';
declare const ShopOutline: IconDefinition;
export default ShopOutline;
