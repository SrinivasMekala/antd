import { IconDefinition } from '../types';
declare const ScheduleOutline: IconDefinition;
export default ScheduleOutline;
