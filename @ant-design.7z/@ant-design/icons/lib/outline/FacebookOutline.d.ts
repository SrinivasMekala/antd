import { IconDefinition } from '../types';
declare const FacebookOutline: IconDefinition;
export default FacebookOutline;
