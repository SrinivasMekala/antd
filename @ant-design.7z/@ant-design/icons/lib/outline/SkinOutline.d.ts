import { IconDefinition } from '../types';
declare const SkinOutline: IconDefinition;
export default SkinOutline;
