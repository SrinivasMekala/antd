import { IconDefinition } from '../types';
declare const SwapRightOutline: IconDefinition;
export default SwapRightOutline;
