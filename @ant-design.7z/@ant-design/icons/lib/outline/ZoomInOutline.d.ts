import { IconDefinition } from '../types';
declare const ZoomInOutline: IconDefinition;
export default ZoomInOutline;
