import { IconDefinition } from '../types';
declare const TableOutline: IconDefinition;
export default TableOutline;
