import { IconDefinition } from '../types';
declare const TabletOutline: IconDefinition;
export default TabletOutline;
