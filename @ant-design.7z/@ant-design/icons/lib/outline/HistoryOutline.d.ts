import { IconDefinition } from '../types';
declare const HistoryOutline: IconDefinition;
export default HistoryOutline;
