import { IconDefinition } from '../types';
declare const StepBackwardOutline: IconDefinition;
export default StepBackwardOutline;
