import { IconDefinition } from '../types';
declare const WomanOutline: IconDefinition;
export default WomanOutline;
