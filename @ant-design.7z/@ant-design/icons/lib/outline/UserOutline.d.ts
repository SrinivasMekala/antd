import { IconDefinition } from '../types';
declare const UserOutline: IconDefinition;
export default UserOutline;
