import { IconDefinition } from '../types';
declare const EllipsisOutline: IconDefinition;
export default EllipsisOutline;
