import { IconDefinition } from '../types';
declare const UpCircleOutline: IconDefinition;
export default UpCircleOutline;
