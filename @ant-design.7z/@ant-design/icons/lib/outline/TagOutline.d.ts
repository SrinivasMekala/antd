import { IconDefinition } from '../types';
declare const TagOutline: IconDefinition;
export default TagOutline;
