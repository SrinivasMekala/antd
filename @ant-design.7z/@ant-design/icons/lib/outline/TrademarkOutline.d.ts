import { IconDefinition } from '../types';
declare const TrademarkOutline: IconDefinition;
export default TrademarkOutline;
