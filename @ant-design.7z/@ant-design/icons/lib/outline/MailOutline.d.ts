import { IconDefinition } from '../types';
declare const MailOutline: IconDefinition;
export default MailOutline;
