import { IconDefinition } from '../types';
declare const TransactionOutline: IconDefinition;
export default TransactionOutline;
