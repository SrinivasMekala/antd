import { IconDefinition } from '../types';
declare const SkypeOutline: IconDefinition;
export default SkypeOutline;
