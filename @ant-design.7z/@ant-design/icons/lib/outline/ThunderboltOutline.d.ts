import { IconDefinition } from '../types';
declare const ThunderboltOutline: IconDefinition;
export default ThunderboltOutline;
