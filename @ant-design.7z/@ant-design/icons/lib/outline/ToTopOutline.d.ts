import { IconDefinition } from '../types';
declare const ToTopOutline: IconDefinition;
export default ToTopOutline;
