import { IconDefinition } from '../types';
declare const ToolOutline: IconDefinition;
export default ToolOutline;
