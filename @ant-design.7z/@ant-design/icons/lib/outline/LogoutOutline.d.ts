import { IconDefinition } from '../types';
declare const LogoutOutline: IconDefinition;
export default LogoutOutline;
