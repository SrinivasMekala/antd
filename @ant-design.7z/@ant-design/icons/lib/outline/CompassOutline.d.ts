import { IconDefinition } from '../types';
declare const CompassOutline: IconDefinition;
export default CompassOutline;
