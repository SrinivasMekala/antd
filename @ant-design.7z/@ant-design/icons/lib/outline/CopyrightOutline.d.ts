import { IconDefinition } from '../types';
declare const CopyrightOutline: IconDefinition;
export default CopyrightOutline;
