import { IconDefinition } from '../types';
declare const WechatOutline: IconDefinition;
export default WechatOutline;
