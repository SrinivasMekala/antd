import { IconDefinition } from '../types';
declare const SortDescendingOutline: IconDefinition;
export default SortDescendingOutline;
