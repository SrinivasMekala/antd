import { IconDefinition } from '../types';
declare const StepForwardOutline: IconDefinition;
export default StepForwardOutline;
