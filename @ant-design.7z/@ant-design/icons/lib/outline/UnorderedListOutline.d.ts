import { IconDefinition } from '../types';
declare const UnorderedListOutline: IconDefinition;
export default UnorderedListOutline;
