import { IconDefinition } from '../types';
declare const WeiboSquareOutline: IconDefinition;
export default WeiboSquareOutline;
