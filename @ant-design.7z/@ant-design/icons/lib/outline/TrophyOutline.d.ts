import { IconDefinition } from '../types';
declare const TrophyOutline: IconDefinition;
export default TrophyOutline;
