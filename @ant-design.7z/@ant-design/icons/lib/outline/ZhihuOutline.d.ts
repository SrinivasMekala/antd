import { IconDefinition } from '../types';
declare const ZhihuOutline: IconDefinition;
export default ZhihuOutline;
