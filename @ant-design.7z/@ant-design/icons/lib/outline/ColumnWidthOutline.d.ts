import { IconDefinition } from '../types';
declare const ColumnWidthOutline: IconDefinition;
export default ColumnWidthOutline;
