import { IconDefinition } from '../types';
declare const UpOutline: IconDefinition;
export default UpOutline;
