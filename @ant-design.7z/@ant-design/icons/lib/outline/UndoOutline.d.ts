import { IconDefinition } from '../types';
declare const UndoOutline: IconDefinition;
export default UndoOutline;
