import { IconDefinition } from '../types';
declare const AlipaySquareFill: IconDefinition;
export default AlipaySquareFill;
