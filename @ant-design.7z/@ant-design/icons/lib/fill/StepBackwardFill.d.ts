import { IconDefinition } from '../types';
declare const StepBackwardFill: IconDefinition;
export default StepBackwardFill;
