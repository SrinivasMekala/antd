import { IconDefinition } from '../types';
declare const WeiboSquareFill: IconDefinition;
export default WeiboSquareFill;
