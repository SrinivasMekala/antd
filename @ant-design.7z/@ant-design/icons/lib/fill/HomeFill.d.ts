import { IconDefinition } from '../types';
declare const HomeFill: IconDefinition;
export default HomeFill;
