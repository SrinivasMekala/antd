import { IconDefinition } from '../types';
declare const PropertySafetyFill: IconDefinition;
export default PropertySafetyFill;
