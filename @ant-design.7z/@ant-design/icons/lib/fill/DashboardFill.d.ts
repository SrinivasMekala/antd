import { IconDefinition } from '../types';
declare const DashboardFill: IconDefinition;
export default DashboardFill;
