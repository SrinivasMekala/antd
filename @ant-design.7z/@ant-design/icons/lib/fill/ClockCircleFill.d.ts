import { IconDefinition } from '../types';
declare const ClockCircleFill: IconDefinition;
export default ClockCircleFill;
