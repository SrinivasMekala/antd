import { IconDefinition } from '../types';
declare const FlagFill: IconDefinition;
export default FlagFill;
