import { IconDefinition } from '../types';
declare const AmazonSquareFill: IconDefinition;
export default AmazonSquareFill;
