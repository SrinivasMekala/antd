import { IconDefinition } from '../types';
declare const InterationFill: IconDefinition;
export default InterationFill;
