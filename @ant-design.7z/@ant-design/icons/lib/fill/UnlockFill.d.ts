import { IconDefinition } from '../types';
declare const UnlockFill: IconDefinition;
export default UnlockFill;
