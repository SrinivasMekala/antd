import { IconDefinition } from '../types';
declare const RocketFill: IconDefinition;
export default RocketFill;
