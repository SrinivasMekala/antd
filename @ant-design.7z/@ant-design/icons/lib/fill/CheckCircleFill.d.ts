import { IconDefinition } from '../types';
declare const CheckCircleFill: IconDefinition;
export default CheckCircleFill;
