import { IconDefinition } from '../types';
declare const EyeInvisibleFill: IconDefinition;
export default EyeInvisibleFill;
