export { default, IconProps, TwoToneColorPaletteSetter, TwoToneColorPalette } from './components/Icon';
